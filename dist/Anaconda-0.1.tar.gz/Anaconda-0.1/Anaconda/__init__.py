"""This module is called Anaconda

.. moduleauthor:: Christian Gram Kalhauge <kalhauge@cbs.dtu.dk>

"""

__all__ = ['AMath','AssociationMining','SOM','Table']